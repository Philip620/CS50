https://docs.cs50.net/2018/x/psets/2/caesar/caesar.html
