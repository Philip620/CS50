# Week 6

The first lecture in Python. The problem set includes the reimplementation of previous problems and two new ones.

Python's grammar is much more user-friendly while needs to memorize more stuff.

The new problems include data processing with CSV files which foreshadows the SQL.