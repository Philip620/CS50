name = input("What is your name?\n")
print(f"hello, {name}\n")