# Week 9

Web application development. **Another excellent problem**, Including the front-end and back-end, using Python with Flask and SQL, chains the latter half of the course into a whole.

Modify the code framework a lot thinking there's no check50. Used the flash function provided by Flask based on the session, but was unable to pass check50, having to change back to the given framework, which is an unsatisfying experience.