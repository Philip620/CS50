# Week 9

Web应用开发。**又一出色作业题**，涉及前后端，通过Python调用Flask框架实现Web应用，调用SQL作为后端数据库，很好地将近四次课的内容串为一个整体。

以为没有check50，所以将模板大改特改，用Flask提供的基于session的flash功能代替apology页面，结果check50过不去，最后又得改回模板形式，算是个略不满意的地方。