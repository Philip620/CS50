# A Perfect Number

#### Video Demo:  https://youtu.be/mV-xicyVBao


#### Description:

##### A number is called a "perfect number" if it is exactly equal to the sum of its factors. For example, 6=1+2+3. Program to find all the perfect numbers within 1000



For this question, I usually start with a simple one, break it down into multiple steps, and solve it step by step.

First of all, we should understand what a perfect number is. From the question, if a number is exactly equal to the sum of its factors, this number is called a "perfect number"

For example, 6 is a perfect number, because its factors are 1, 2, 3, which add up to 6

For example, 8 is not a perfect number, its factors are 1, 2, 4, which add up to 7, which are not equal, so it is not

For example, 9 is not a perfect number. Its factors are 1 and 3, which add up to 4, which are not equal, so it is not

You may think it is nonsense, just repeating the topic, but it is not the case, this is relevant and familiar with the topic



Secondly, we need to understand how to find the factor. The so-called factor is divisible, that is, the remainder is 0, that is, the remainder is 0. I wrote a small code, the code is as follows:



```python3
# 如何找出一个数的因子
n=int(input("请输入一个数：")) # 输入一个数
for i in range(1,n): # 循环1到该数之间
 if n % i ==0: #如果取余为0
 print(i) # 那么该数就是因子
```

Then, there are two ways to judge whether the number is complete or not

One is to subtract the factor from the number while finding the factor. If the final result is 0, then the number is complete. The code is as follows:

The other is to find all the factors, then add them up and compare with the original number, if they are equal, the number is complete.

```text
for i in range(1,1001):
    xlist=[]
    for j in range(1,i//2+1):
        if i % j==0:
            xlist.append(j)
    if sum(xlist)==i:
        print(i)
        print(xlist)
```



After answering, both answers are acceptable



Compare:

1. In the above two programs, the upper limit range of the inner loop is i and the other is i//2+1. What is the difference? Why do you do this?

Answer: It can reduce the number of inner loops and improve program efficiency.

1. Among the above two programs, the second program can not only output the perfect number, but also the factor of the perfect number. Can you modify the first program to also output the factor of the perfect number? Answer: Yes, refer to the top answerFor this question, I usually start with a simple one, break it down into multiple steps, and solve it step by step.

First of all, we should understand what a perfect number is. From the question, if a number is exactly equal to the sum of its factors, this number is called a "perfect number"

For example, 6 is a perfect number, because its factors are 1, 2, 3, which add up to 6

For example, 8 is not a perfect number, its factors are 1, 2, 4, which add up to 7, which are not equal, so it is not

For example, 9 is not a perfect number. Its factors are 1 and 3, which add up to 4, which are not equal, so it is not

You may think it is nonsense, just repeating the topic, but it is not the case, this is relevant and familiar with the topic



Secondly, we need to understand how to find the factor. The so-called factor is divisible, that is, the remainder is 0, that is, the remainder is 0. I wrote a small code, the code is as follows:



```python3
# 如何找出一个数的因子
n=int(input("请输入一个数：")) # 输入一个数
for i in range(1,n): # 循环1到该数之间
 if n % i ==0: #如果取余为0
 print(i) # 那么该数就是因子
```

Then, there are two ways to judge whether the number is complete or not

One is to subtract the factor from the number while finding the factor. If the final result is 0, then the number is complete. The code is as follows:

The other is to find all the factors, then add them up and compare with the original number, if they are equal, the number is complete.
For this question, I usually start with a simple one, break it down into multiple steps, and solve it step by step.

First of all, we should understand what a perfect number is. From the question, if a number is exactly equal to the sum of its factors, this number is called a "perfect number"

For example, 6 is a perfect number, because its factors are 1, 2, 3, which add up to 6

For example, 8 is not a perfect number, its factors are 1, 2, 4, which add up to 7, which are not equal, so it is not

For example, 9 is not a perfect number. Its factors are 1 and 3, which add up to 4, which are not equal, so it is not

You may think it is nonsense, just repeating the topic, but it is not the case, this is relevant and familiar with the topic



Secondly, we need to understand how to find the factor. The so-called factor is divisible, that is, the remainder is 0, that is, the remainder is 0. I wrote a small code, the code is as follows:



```python3
# 如何找出一个数的因子
n=int(input("请输入一个数：")) # 输入一个数
for i in range(1,n): # 循环1到该数之间
 if n % i ==0: #如果取余为0
 print(i) # 那么该数就是因子
```

Then, there are two ways to judge whether the number is complete or not

One is to subtract the factor from the number while finding the factor. If the final result is 0, then the number is complete. The code is as follows:

The other is to find all the factors, then add them up and compare with the original number, if they are equal, the number is complete.
