# Week 8

Open-ended problems are annoying.

Took quite a whole day skimming through the HTML, CSS and JS tutorials on W3Shools, and also read about the tutorials of bootstrap and W3.CSS. Front-end stuff is complicated.

Made a homepage and a navbar for my resource station. Might share the project after completion.