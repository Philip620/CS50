https://docs.cs50.net/2018/x/psets/1/cash/cash.html
