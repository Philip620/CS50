# Week 7

Movies and songs used data from real databases and are interesting.

Fiftyville is **highly recommended** to all SQL beginners. With elegant design and moderate difficulty, solving the problem is as fun as playing games. Could be made into an independent game.
